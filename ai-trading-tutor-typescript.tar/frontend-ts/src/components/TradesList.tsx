import React from 'react';
import { Trade } from '../types/api';

interface TradesListProps {
  trades: Trade[];
  onSelectTrade: (index: number) => void;
  selectedTrade: number | null;
}

const TradesList: React.FC<TradesListProps> = ({ trades, onSelectTrade, selectedTrade }) => {
  return (
    <div className="trades-table-container">
      <table className="trades-table">
        <thead>
          <tr>
            <th>#</th>
            <th>Entry Date</th>
            <th>Exit Date</th>
            <th>Entry Price</th>
            <th>Exit Price</th>
            <th>P&L</th>
            <th>Probability</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {trades.map((trade, index) => (
            <tr 
              key={index} 
              className={`${trade.pnl > 0 ? 'winning-trade' : 'losing-trade'} ${selectedTrade === index ? 'selected' : ''}`}
            >
              <td>{index + 1}</td>
              <td>{new Date(trade.entry_date).toLocaleDateString()}</td>
              <td>{new Date(trade.exit_date).toLocaleDateString()}</td>
              <td>${trade.entry_price.toFixed(2)}</td>
              <td>${trade.exit_price.toFixed(2)}</td>
              <td className={trade.pnl > 0 ? 'positive' : 'negative'}>
                {(trade.pnl * 100).toFixed(2)}%
              </td>
              <td>{(trade.bullish_prob * 100).toFixed(1)}%</td>
              <td>
                <button 
                  className="explain-btn"
                  onClick={() => onSelectTrade(index)}
                >
                  Explain
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TradesList;

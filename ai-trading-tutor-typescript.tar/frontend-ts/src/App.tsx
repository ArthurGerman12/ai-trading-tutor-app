import React, { useState, useEffect } from 'react';
import axios from 'axios';
import EquityCurveChart from './components/EquityCurveChart';
import MetricsCard from './components/MetricsCard';
import TradesList from './components/TradesList';
import FeatureComparison from './components/FeatureComparison';
import FeatureImportance from './components/FeatureImportance';
import { BacktestResponse, TradeExplanation, TabType } from './types/api';
import './App.css';

const API_BASE_URL = 'http://localhost:8000';

const App: React.FC = () => {
  const [backtestData, setBacktestData] = useState<BacktestResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [selectedTrade, setSelectedTrade] = useState<number | null>(null);
  const [tradeExplanation, setTradeExplanation] = useState<TradeExplanation | null>(null);

  const fetchBacktest = async (): Promise<void> => {
    setLoading(true);
    setError(null);
    try {
      const response = await axios.get<BacktestResponse>(`${API_BASE_URL}/api/backtest`);
      setBacktestData(response.data);
    } catch (err) {
      setError((err as Error).message || 'Failed to fetch backtest data');
    } finally {
      setLoading(false);
    }
  };

  const fetchTradeExplanation = async (tradeIndex: number): Promise<void> => {
    try {
      const response = await axios.get<TradeExplanation>(`${API_BASE_URL}/api/trades/${tradeIndex}/explain`);
      setTradeExplanation(response.data);
      setSelectedTrade(tradeIndex);
    } catch (err) {
      console.error('Failed to fetch trade explanation:', err);
    }
  };

  useEffect(() => {
    fetchBacktest();
  }, []);

  if (loading) {
    return (
      <div className="app">
        <div className="loading-container">
          <div className="spinner"></div>
          <p>Running backtest analysis...</p>
          <p className="loading-note">This may take 30-60 seconds</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="app">
        <div className="error-container">
          <h2>Error</h2>
          <p>{error}</p>
          <button onClick={fetchBacktest}>Retry</button>
        </div>
      </div>
    );
  }

  if (!backtestData) {
    return (
      <div className="app">
        <div className="loading-container">
          <p>No data available</p>
          <button onClick={fetchBacktest}>Load Data</button>
        </div>
      </div>
    );
  }

  return (
    <div className="app">
      <header className="app-header">
        <h1>📈 AI Trading Tutor</h1>
        <p className="subtitle">Educational Market Intelligence Platform</p>
        <div className="disclaimer">
          ⚠️ Educational purposes only - Not financial advice
        </div>
      </header>

      <nav className="tabs">
        <button 
          className={activeTab === 'overview' ? 'tab active' : 'tab'}
          onClick={() => setActiveTab('overview')}
        >
          Overview
        </button>
        <button 
          className={activeTab === 'trades' ? 'tab active' : 'tab'}
          onClick={() => setActiveTab('trades')}
        >
          Trades Analysis
        </button>
        <button 
          className={activeTab === 'features' ? 'tab active' : 'tab'}
          onClick={() => setActiveTab('features')}
        >
          Feature Insights
        </button>
        <button 
          className={activeTab === 'education' ? 'tab active' : 'tab'}
          onClick={() => setActiveTab('education')}
        >
          Learning
        </button>
      </nav>

      <main className="content">
        {activeTab === 'overview' && (
          <>
            <section className="metrics-section">
              <h2>Performance Metrics</h2>
              <div className="metrics-grid">
                <MetricsCard 
                  title="ML Strategy" 
                  metrics={backtestData.metrics}
                  type="strategy"
                />
                <MetricsCard 
                  title="Buy & Hold" 
                  metrics={backtestData.buy_hold_metrics}
                  type="baseline"
                />
              </div>
            </section>

            <section className="chart-section">
              <h2>Equity Curve</h2>
              <EquityCurveChart data={backtestData.equity_curve} />
            </section>

            <section className="trades-summary">
              <h2>Trade Summary</h2>
              <div className="summary-stats">
                <div className="stat">
                  <span className="stat-label">Total Trades</span>
                  <span className="stat-value">{backtestData.metrics.num_trades}</span>
                </div>
                <div className="stat winning">
                  <span className="stat-label">Winning</span>
                  <span className="stat-value">{backtestData.winning_trades}</span>
                </div>
                <div className="stat losing">
                  <span className="stat-label">Losing</span>
                  <span className="stat-value">{backtestData.losing_trades}</span>
                </div>
                <div className="stat">
                  <span className="stat-label">Win Rate</span>
                  <span className="stat-value">
                    {((backtestData.winning_trades / backtestData.metrics.num_trades!) * 100).toFixed(1)}%
                  </span>
                </div>
              </div>
            </section>
          </>
        )}

        {activeTab === 'trades' && (
          <>
            <section>
              <h2>All Trades</h2>
              <TradesList 
                trades={backtestData.trades} 
                onSelectTrade={fetchTradeExplanation}
                selectedTrade={selectedTrade}
              />
            </section>

            {tradeExplanation && (
              <section className="explanation-section">
                <h2>AI Explanation</h2>
                <div className="explanation-card">
                  <div className="trade-info">
                    <p><strong>Entry:</strong> {new Date(tradeExplanation.trade.entry_date).toLocaleDateString()}</p>
                    <p><strong>Exit:</strong> {new Date(tradeExplanation.trade.exit_date).toLocaleDateString()}</p>
                    <p><strong>P&L:</strong> <span className={tradeExplanation.trade.pnl > 0 ? 'positive' : 'negative'}>
                      {(tradeExplanation.trade.pnl * 100).toFixed(2)}%
                    </span></p>
                  </div>
                  <div className="explanation-text">
                    {tradeExplanation.explanation}
                  </div>
                </div>
              </section>
            )}
          </>
        )}

        {activeTab === 'features' && (
          <>
            <section>
              <h2>Winning vs Losing Trade Features</h2>
              <FeatureComparison data={backtestData.feature_comparison} />
            </section>

            <section>
              <h2>Feature Importance</h2>
              <FeatureImportance />
            </section>
          </>
        )}

        {activeTab === 'education' && (
          <>
            <section className="education-section">
              <h2>Understanding the Results</h2>
              
              <div className="education-card">
                <h3>What is Max Drawdown?</h3>
                <p>{backtestData.max_drawdown_explanation}</p>
              </div>

              <div className="education-card">
                <h3>Key Lessons</h3>
                <ul>
                  <li><strong>Probabilities, not certainties:</strong> The model estimates likelihood, not guarantees</li>
                  <li><strong>Risk management matters:</strong> Even good signals can fail in volatile markets</li>
                  <li><strong>Drawdowns are inevitable:</strong> All strategies face periods of losses</li>
                  <li><strong>Past performance ≠ Future results:</strong> Historical patterns don't always repeat</li>
                </ul>
              </div>

              <div className="education-card">
                <h3>Strategy Logic</h3>
                <ul>
                  <li>Enter when bullish probability exceeds threshold (0.65)</li>
                  <li>Hold for fixed period (5 days)</li>
                  <li>Exit automatically regardless of outcome</li>
                  <li>Reduce position size after 3 consecutive losses</li>
                  <li>Monitor volatility to avoid high-risk entries</li>
                </ul>
              </div>

              <div className="education-card philosophy">
                <h3>Project Philosophy</h3>
                <blockquote>
                  "The goal is not to beat the market — the goal is to understand it."
                </blockquote>
                <p>
                  This platform teaches market behavior through simulation and analysis.
                  It shows why strategies succeed or fail, helping you develop realistic
                  expectations about trading and investing.
                </p>
              </div>
            </section>
          </>
        )}
      </main>

      <footer className="app-footer">
        <p>AI Trading Tutor v1.0 | Educational Platform</p>
        <button onClick={fetchBacktest} className="refresh-btn">
          🔄 Refresh Data
        </button>
      </footer>
    </div>
  );
};

export default App;
